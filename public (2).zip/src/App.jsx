import React from 'react'
import Main from './Formik_Yup/Main'
import Main2 from './TanstackTable/Main2'

function App() {
  return (
    <div>
      {/* <Main/> */}
      <Main2/>
    </div>
  )
}

export default App