import React from 'react'
import Formikone from './Formikone'
import Formiktwo from './Formiktwo'

function Main() {
  return (
    <div>
        {/* <Formikone/> */}
        <Formiktwo/>
    </div>
  )
}

export default Main