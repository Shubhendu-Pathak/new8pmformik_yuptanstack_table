import React from 'react'
import Main from './Formik_Yup/Main'

function App() {
  return (
    <div>
      <Main/>
    </div>
  )
}

export default App